/**
  shortcut for the jQuery onDOMready event
*/
$( function() {
  /** 
    Add your code here.
  */
});