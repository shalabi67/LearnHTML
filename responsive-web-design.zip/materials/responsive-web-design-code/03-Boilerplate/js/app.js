// When you change APP, be sure to update it in mylibs/util.js
var APP = {
  
  methodName: function() {
    
  },
  
  // Initializers
  common: {
    init: function() { 
      
    },
    finalize: function() {
      
    }
  },
  
  bodyId_or_className: {
    init: function() { 

    },
    finalize: function() { 
      
    }
  }
};

$(document).ready(UTIL.loadEvents);